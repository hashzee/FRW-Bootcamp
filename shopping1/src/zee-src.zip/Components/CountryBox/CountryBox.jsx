import React, { useEffect, useState } from "react";

function CountryBox(props) {
  let countryCode = props.countryCode;
  let url ="https://api.thevirustracker.com/free-api?countryTotal=" + countryCode;

  const [globalData, setGlobalData] = useState({});
  const [countryName, setCountryName] = useState("");

  useEffect(() => {
    getData(url);

    async function getData(url) {
      const response = await fetch(url);
      let data = await response.json(); // convert to json
       //console.log(data); 
      const countryname = data.countrydata[0].info.title;
      delete data.countrydata[0].info;
      setCountryName(countryname);
      setGlobalData(data.countrydata[0]);
    }
  }, []);
    

  return (
    <div>
      <h3>
        Stats for: {countryCode} {countryName}
        {/* {countryname} */}
        {/* // countryCode is defined as var above, countryName is a state  */}
      </h3>

      <div>
        {Object.keys(globalData).map((key, ind) => {
          return (
            <div key={ind}>
              <div>
                <h3>
                  {key.replace(/_/g, " ").toUpperCase()}{" "}
                </h3>
                <h3> {globalData[key]} </h3>
                {/* //ERR if  .info not deleted */}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default CountryBox;
