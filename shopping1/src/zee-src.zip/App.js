import React from 'react';
import CountryBox from './Components/CountryBox/CountryBox';
import './App.css';

function App() {
  
  var countryCode = window.prompt("Enter Country 2 letter code: ");

  return (
    <div className="App">
        <CountryBox countryCode={countryCode} />
    </div>
  );
}

export default App;
